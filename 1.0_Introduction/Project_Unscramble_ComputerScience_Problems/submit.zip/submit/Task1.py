"""
Read file into texts and calls.
It's ok if you don't understand how to read files.
"""
import csv
with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

"""
TASK 1:
How many different telephone numbers are there in the records? 
Print a message:
"There are <count> different telephone numbers in the records."
"""
all_numbers = set()

# Unique numbers in calls
for call_number in calls:
    all_numbers.add(call_number[0])
    all_numbers.add(call_number[1])

# Unique numbers in text
for text_number in texts:
    all_numbers.add(text_number[0])
    all_numbers.add(text_number[1])

print("There are " + str(len(all_numbers))+ " different telephone numbers in the records.")
