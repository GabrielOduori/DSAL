"""
Read file into texts and calls.
It's ok if you don't understand how to read files
"""
import csv
from collections import defaultdict
with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

"""
TASK 2: Which telephone number spent the longest time on the phone
during the period? Don't forget that time spent answering a call is
also time spent on the phone.
Print a message:
"<telephone number> spent the longest time, <total time> seconds, on the phone during 
September 2016.".
"""


# build dictionary of calls (keys) and duration (values)
call_dict = defaultdict(list)

def call_duration(calls):
    
    for call in calls:
        calling_number, called_number = call[0], call[1]
        duration = call[3]
        
        if call_dict.keys() == calling_number:
            call_dict[calling_number] = [duration]
        else:
            call_dict[calling_number].append(duration)

        if call_dict.keys() == called_number:
            call_dict[called_number] = [duration]
        else:
            call_dict[called_number].append(duration)

call_duration(calls)


# build a dictionary for total duration for each number         
phone_duration = {}
for key, value in call_dict.items():
    phone_duration[key] = sum(map(int, value))

# get max value of values in new duration dictionary and print out key and value
longest_duration = max(phone_duration, key=phone_duration.get)  
print(longest_duration, 'spent the longest time,', phone_duration[longest_duration], 'seconds, on the phone during September 2016.')

